function menentukan() {
    var angka = document.myForm.nilai
    for (let i = 1; i <= angka; i++)
        if ((i % 2) == 0) {
            result = `${i}" adalah bilangan genap"`
        } else if ((i % 2) == 1) {
        result = `${i}" adalah bilangan ganjil"`
    }
}